Quanah 魔方工具 · Windows 10/11 64 位

1. 解压整个 ZIP。保留 Quanah-Cube.exe、quanah_cube.py、runtime 和 ocr 的相对位置。
2. 双击 Quanah-Cube.exe，选 1 试读。按脚本提示操作，在 5 秒内切回魔方结果页。
3. 确认左右 CP、材料和单次消耗都读对后，重新打开程序，选 2 开始。
4. 右侧 CP 更高会播放两声上扬音，停在结果页等你选择 AFTER。
   材料不足会播放两声下降音。按住 F8 或切出游戏都可停止。
5. 按键后等待约 0.20 秒，独立浮动 ±0.04 秒。界面识别和服务器响应也会占用时间。
   识别到 Please try again later. 后同样稍等约 0.20 秒再按回车。

无需另外安装 Python 或 Tesseract。截图区域依据参考图的客户区比例。
